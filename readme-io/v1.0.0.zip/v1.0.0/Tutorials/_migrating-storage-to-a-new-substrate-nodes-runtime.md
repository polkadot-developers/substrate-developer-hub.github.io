---
title: "Migrating Storage to a new Substrate Node's Runtime"
excerpt: ""
---
* **FIXME** - see discussion in substrate-technical - https://matrix.to/#/!HzySYSaIhtyWrwiwEV:matrix.org/$1542803234296001lajTq:matrix.org