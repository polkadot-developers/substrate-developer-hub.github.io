---
title: "Substrate Collectables Workshop"
excerpt: ""
---

https://shawntabrizi.github.io/substrate-collectables-workshop/