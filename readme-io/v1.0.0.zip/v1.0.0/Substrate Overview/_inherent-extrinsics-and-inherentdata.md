---
title: "Inherent Extrinsics and InherentData"
excerpt: "How to get data from the node author onto the chain"
---
TODO