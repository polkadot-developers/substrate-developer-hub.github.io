---
title: "Telemetry"
excerpt: "Reporting and collating node data"
---
Substrate comes inbuilt with major telemetry capabilities.

## The Substrate Telemetry protocol

TODO: maciej

## The `telemetry` crate

TODO: maciej

## Setting up a web telemetry server

TODO: maciej